# Author        =   Fowzy Alsaud
# Date          =   Oct, 20th, 2021
# Class         =   CMPS 4143 - Dr. Das
# Assignment    =   Assignment #3 - Part 3
# Descirption   =   Creating a program that will has a function that converts a string to a 32 bit signed integer
import re       # import re for regex
def myAtoi(s):  # my string called s as we see here 
    # using regex(regular experssion) to filter my data out
    # removing spaces and words and double quotes, explain:
    #   -\s means white spaces
    #   -[A-za-z] remove range from A-Z CAPS and small letters a-z
    #   -\" removing double quotes"
    regex = int(re.sub('([A-Za-z\s\"])', '', s))    # declared my regex pattern and use re.sub to replace all the data that is not nessorry with blank/remove
    if (regex < (-2 ** 31)):    # if the number is minus and out of range of 32 bit return negative -2^31
        return int(-2 ** 31)
    elif(regex > (2 ** 31-1)):  # if the number is positive and out of range of 32 bit return 2^31-1
        return int(2 ** 31-1)
    else:                       # else means if the number is normal and in the right range just return match which is an integer as required
        return regex    
    
sInput = str(input('Please enter an input: ')) # taking the input from the user as string
print(myAtoi(sInput)) # pass the string to myAtoi function which I will explain later