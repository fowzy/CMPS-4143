
 // Inheritance : Son inherite features from father
class Son extends Father{
    // Example of Polymorphism: Dynamic/Runtime/Overriding
    public void eat(){
        System.out.println("Son eats alot!.");
    }
}