
// Abstraction: the following class can't be inhertie
public abstract class Mother {
    abstract void cook();
}
