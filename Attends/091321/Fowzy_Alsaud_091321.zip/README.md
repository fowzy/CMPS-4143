## Inherinates 
    - Remember:
      - Parent class called Base class
      - Child class called drived class
      - You can't inherinate the constructor 
      - You inherinate the attributes/variables and methods/behaviors 
      - this.VarName used inside the class referring to the local variable, look at it Bicycle class
      - if you write the same method name in the child class the child method will overwrite the parent method.
      - the example that we made in the class is Single inhertinace example : Bicycle, MountainBike, Driver.

### By:
    - Fowzy Alsaud
### Date:
    - 09/13/2021
