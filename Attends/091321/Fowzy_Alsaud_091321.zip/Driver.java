public class Driver {
    public static void main(String[] args) {
        MountainBike mBike = new MountainBike(5, 120, 10);
        System.out.println(mBike.showStatus());
    }
}
